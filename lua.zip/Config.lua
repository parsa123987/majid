do
local _ = {

      logs = 640960815, -- ایدی عددی کانال
	  Usersudo = '@ArminNy', -- ایدی سودو همراه @
      Mehdi = 640960815, -- ایدی سودو
      ReacTanceSudos = {640960815,626823162}, -- ایدی سودو ها
      ReacTance_id = 626823162, -- ایدی ربات
      ReaTanceToken = '626823162:AAEf6crvLGqfhGxD7740RXRycpQkUfbqCRY', -- توکن
      channel = '@DELTATM', -- ایدی کانال
      support = 'https://t.me/joinchat/JjRJL0ysZ8hrUC6IJljOoA', -- لینک گروه
      botusername = '@D_AntiSpam_bot', -- ایدی ربات
	  
}
return _
end
